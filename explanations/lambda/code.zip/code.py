def lambda_handler(event, context):
    return {
        "message": "Hello world from a lambda created with AWS CLI"
    }