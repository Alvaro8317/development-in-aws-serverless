let counter;
let lastInvocationTime = null;
let coldStart = true;

function handleColdStart() {
  if (coldStart) {
    console.log("⏳ Cold start detectado. Reiniciando el contador...");
    counter = 0;
    coldStart = false;
  }
}

function updateLastInvocationTime() {
  const now = new Date();
  lastInvocationTime = now.toISOString();
}

exports.handler = async (event) => {
  handleColdStart();

  updateLastInvocationTime();

  const message = coldStart
    ? `❄️ Está haciendo frío, ¿no? Contador reiniciado a 0. Ahora está en: ${counter}`
    : `🔥 Contador caliente: ${counter}. Última invocación: ${lastInvocationTime}`;

  counter++;

  console.log("✅ Estado actual del contador:", counter);

  return {
    statusCode: 200,
    body: JSON.stringify({
      message: message,
      counter: counter,
      lastInvocationTime: lastInvocationTime,
    }),
  };
};
